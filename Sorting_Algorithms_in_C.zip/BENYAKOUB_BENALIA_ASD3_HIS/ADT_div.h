#ifndef ADT_DIV_H
#define ADT_DIV_H_



// CET HEADER CONTIENT UNE SEUL PROCEDURE DIV
    // CONTIENT ELEMENTS DE CODE COMMUN DANS TOUT LES CAS DE TRI





///-------------///----------------////-----------------------------///
void TRI_div(int TAB,int taille,int TypeDeTri)
{


                double exe=ExeTime(TAB,taille,TypeDeTri); // CALCULER TEM D'EXE EN TRIANT LE TAB

                if(taille<100){

				  Color(176); Afficher(TAB,taille);Color(15);

			 }else{         CursorPosition(15,5);

                            Color(224);FastTypeWritter("ARRAY SORTED SUCCESSFULY");Color(15);
					}

					puts("\n\n");

					Color(11);

					FastTypeWritter("SORTING TIME ");

					toString(exe);      // AFFICHAGE DE TEMPS



}

 ////-------------------------------///------------------------///------------------------///




#endif // ADT_DIV_H_INCLUDED
