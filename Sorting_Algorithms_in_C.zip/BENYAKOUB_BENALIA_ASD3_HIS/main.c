#include <stdio.h>
#include <stdlib.h>
#include<time.h>
#include<windows.h>

#include"Interface.h"
#include"AlgoTri.h"
#include"ADT_div.h"




extern  int n=0;
extern  int*TAB=NULL,*New_TAB=NULL;
extern  FILE *file=NULL;


void GenTAB_div(){
                    GeneratorScreen(); // POUR DESIGN INTERFACE IHM

                    CursorPosition(2,3);

                    Color(224);printf("SET SIZE= ");Color(15);

                    scanf("%d",&n);             // SCANNER LA TAILLE DU TABLEAU

                    TAB=calloc(n,sizeof(int)); // ALLOUER L'ESPACE POUR TAB

            Remplir(TAB,n);                     //REMPLIR TAB

            Sleep(150);

            New_TAB=calloc(n,sizeof(int));      //ALLOUER ESPACE POUR COPIER TAB AVANT TRI

            CopyTAB(TAB,New_TAB);               //COPIER TAB

            Color(14); CursorPosition(25,5);

            FastTypeWritter("GENERATING...");Color(15);

            Sleep(150);

            GeneratorScreen();



             if( n < 100 ){         //AFFICHER TAB SI TAILLE 100

					Color(176); Afficher(TAB,n);Color(15);
             }else{

                    CursorPosition(14,7);

					Color(224);FastTypeWritter("TABLE GENERATED SUCCESSFULY");Color(15); // SINON AFFICHER MSG
					}
}


void GotoMenu_div(){                            //PROCEDURE POUR DETECTER FRAPPE CLAVIER (ECHAPE BOUTTON)
                        CursorPosition(6,10);

                        Color(48); FastTypeWritter("PRESS ESC");Color(15);

                        int k;

                        do{
                                k = _getch();

                                if (k == 0 || k == 224) {

                                k = _getch();
                                                    }
                        }while(k!=27);

}

///---------------////--------------------------------////---------------------------------------///-/-/


 void CompareTime(int n){                               // CALCULER ET AFFICHER TEMP D'EXE D'UNE ALGO DE TRI
                                                            //EN FONCTION DE TAILLE
                            TAB=calloc(n,sizeof(int));

                            Remplir(TAB,n);

                            New_TAB=calloc(n,sizeof(int));

                            CopyTAB(TAB,New_TAB);

Color(63);
                printf("  %d ",n);
Color(11);
                printf("%lf\t",ExeTime(TAB,n,2));  free(TAB);   TAB=calloc(n,sizeof(int));  CopyTAB(New_TAB,TAB);

                printf("%lf\t",ExeTime(TAB,n,3));    free(TAB); TAB=calloc(n,sizeof(int));  CopyTAB(New_TAB,TAB);

                printf("%lf\t",ExeTime(TAB,n,4));  free(TAB); TAB=calloc(n,sizeof(int));  CopyTAB(New_TAB,TAB);

                printf("%lf\t",ExeTime(TAB,n,5));  free(TAB); TAB=calloc(n,sizeof(int));  CopyTAB(New_TAB,TAB);

                printf("%lf\t\n",ExeTime(TAB,n,6));  free(TAB); TAB=calloc(n,sizeof(int));  CopyTAB(New_TAB,TAB);
Color(15);
 }



 ///-------------------------------------------////------------------------------------///


int main(){
int stop =0;

       OPSCREEN();     sleep(1);   // POUR DESIGN IHM

        PressButtons();

        if((file=fopen("ADT.txt","r"))==NULL){

                puts("ERROR! FILE MISSING");
            }

        printImage(file);       //AFFICHER IMAGE STOCKER DS FICHIER

        fclose(file);

        Loading();  Sleep(500); // IHM*/
int Choix;
do{                 //FAIRE ... JUSQU'AU CHOIX CORRESPANDS A L'UN DES CHOIX

    Menu();
   do{
    system("cls");

    StaticMenu();       //AFFIHCER MENUE

    puts("");

   Color(48);

   FastTypeWritter("CHOOSE");Color(15);

   scanf("%d",&Choix);              // SCANNER CHOIX

    fflush(stdin);                  //NETTOYER TAMPON

   }while(!(Choix>=1 && Choix <=8));

    switch( Choix ){

                        case 1: GenTAB_div(); // GENERER TABLEAU

                                GotoMenu_div(); //RETOURNE VERS MENU
                            break;

                            case 2: SwitchScreen("TRI BULLE    ");

                                    TRI_div(TAB,n,2);   // APPELER TRI DIV 2= CAS DE TRI BULLE

                                    free(TAB);          //LIBIRER TAB APRES AFFICHAGE DU TAB ET CALCULER DE TEMP EXE

                                    TAB=calloc(n,sizeof(int));  // ALLOUER ESPACE DE NV

                                    CopyTAB(New_TAB,TAB);   // COLLER  LES VALEURS INITIALS DE TAB

                                    GotoMenu_div(); // ALLER VERS MENU
                                    break;

                            case 3: SwitchScreen("INSERTION");

                                    TRI_div(TAB,n,3); // 3= CAS  TRI INSERTION

                                    free(TAB);              // MEME PROCESSUS APRES TRI

                                    TAB=calloc(n,sizeof(int));

                                    CopyTAB(New_TAB,TAB);

                                    GotoMenu_div();

                                    break;

                        case 4: SwitchScreen("SELECTION");

                                TRI_div(TAB,n,4);   // 4= TRI SELECTION

                                free(TAB);          // MM PROCESSUS

                                TAB=calloc(n,sizeof(int));

                                CopyTAB(New_TAB,TAB);

                                GotoMenu_div();

                            break;

                        case 5: SwitchScreen("RAPIDE   ");

                                TRI_div(TAB,n,5);       // 5=TRI RAPIDE

                                TAB=calloc(n,sizeof(int)); //MM PREOCESSUS

                                CopyTAB(New_TAB,TAB);

                                GotoMenu_div();
                                break;

                        case 6:SwitchScreen("FUSION   ");

                                TRI_div(TAB,n,6);   // TRI FUSION

                                TAB=calloc(n,sizeof(int)); // AGAIN AND AGAIN

                                CopyTAB(New_TAB,TAB);

                                GotoMenu_div();
        break;

    case 7:     system("cls");

                Color(63);

                printf("\t BULLE\t\tSELECTION\tINSERION\t RAPIDE \t FUSION \n"); // AFFICHER LES TRI DANS UN TABLEAU SANS
                                                                                    //IMPLEMENTATION D'UN TABLEAU
                Color(15);

                    CompareTime(10000); Sleep(300);

                    CompareTime(20000);Sleep(300);

                    CompareTime(100000);Sleep(300);

                    CompareTime(500000);Sleep(300);



                    GotoMenu_div();
        break;

    case 8: exit(-1); // CAS D'EXIT
   }


}while(!stop);



    return 0;
    }




