#ifndef EXTRAMETHODS_H
#define EXTRAMETHODS_H


//CET HEADER CONTIENT DE METHODES CREER AU BUT DE FACILITER LA LECTURE DU CODE
//EN MEME TEMPS CES METHODES AIDENT A MINIMIZER LE TANT DE CODE

//---------------------------//--------///-------------///----------

void Color(int x){      // COULEUR DU TEEXT

SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),x);
}

//--------------------------------------//---------///-----------
void CursorPosition(int x,int y){       // POSITION DU CUSREUR
    COORD pos;
    pos.X=x;
    pos.Y=y;

SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),pos);
}

//------------------------////--------------------------------///------------------///
void CopyTAB(int MainTAB[],int SubTAB[]){     //COPIERET COLLER CONTENU D'UN TABLEAU
   // fflush(stdin);

    int *ptr=MainTAB;

    int i=0;

    while(*ptr){

        SubTAB[i]= *ptr++;
        //printf("||%d",SubTAB[i]);
        i++;
    }


}
//------------------------////--------------------------------///------------------///

double ExeTime(int T[],int taille,int SortType){ // CALCULE TEMP EXECUTION SELON LE CAS (DE 2 A 6)

   clock_t starts,ends;

  switch(SortType){

    case 2:
            starts=clock(); TriBulle(T,taille); ends=clock();
        break;

    case 3:
            starts=clock(); TriInsertion(T,taille); ends=clock();
        break;

    case 4:
            starts=clock(); TriSelection(T,taille); ends=clock();
        break;

    case 5:
            starts=clock(); TriRapide(T,0,taille); ends=clock();
        break;

    case 6:
            starts=clock(); TriFusion(T,0,taille); ends=clock();
        break;
    }
    double Exe_time= (double)(ends-starts)/CLOCKS_PER_SEC;

    return Exe_time;
}
//------------------------////--------------------------------///------------------///
void Afficher(int T[],int n){   //Afficher le tableau

    puts("");

    for(int i=0;i<n;i++){

        printf("| %d ",T[i]);
    } }
///--------------------------//-------------//--------------//----------//-//

void Remplir(int T[],int n){    //Remplire le tableau

    srand(time(0));

    for(int i=0;i<n;i++){

        T[i]=rand()%(500000-1)+1;
    }}
//------------------------////--------------------------------///------------------///
void TypeWritter(char *p){      // EFFET D'AFFICHAGE ( DESIGN IHM )

    if(*p==NULL){

        return;
    }
    while(*p){

        printf("%c \xDB",*p++);

        Sleep(40);

        printf("\b \b");

        Sleep(70);   }

        Sleep(300);
}
//------------------------////--------------------------------///------------------///
void FastTypeWritter(char *p){ // TYPEWITER MAIS EFFET PLUS RAPIDE

    if(*p==NULL){

        return;
    }
    while(*p){

        printf("%c \xDB",*p++);

        Sleep(10);

        printf("\b \b");

        Sleep(35);   }

        Sleep(300);
}

//-----------------------///-------------------------------////--------//-----
void toString(double exe){  // CONVERTIRE DOUBLE VERS STRING(CHAR ARRAY)

    Color(63);

    Sleep(50);

		char array[20];

		sprintf(array,"%lf S",exe);

		FastTypeWritter(array);

    Color(15);
}

//------------------------////--------------------------------///------------------///

#endif // EXTRAMETHODS_H
