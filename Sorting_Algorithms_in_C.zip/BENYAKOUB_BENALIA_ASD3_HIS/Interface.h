#ifndef Interface_h
#define Interface_h
#include<time.h>
#include <stdlib.h>
#include<windows.h>
#include<conio.h>
#include"ExtraMethods.h"

//CET HEADER IMPLEMETN DES MOTHEDES CREE INITIALEMENT POUR FACILISER LE SWITVHING ENTRE LES DIFFERENTES ZONE
// DU PROGRAMME

void Loading(){

    CursorPosition(35,13);

    Color(14);

    printf("LOADING...");


    CursorPosition(20,15);

    Color(238);

    for(int i=0;i<=37;i++){

        printf("%c",177);

        Sleep(50);
    }
    Color(0);
}
//-----------------------------------

void printImage(FILE *fptr){

    char *read_String;

    read_String=calloc(60,sizeof(char));

    Color(11);

    while(fgets(read_String,sizeof(read_String),fptr)!=NULL){

        printf("%s",read_String);Sleep(15);
    }
    free(read_String);
}


//------------------------------------------


//-----------------------------------------
void GeneratorScreen(){

    system("cls");

    Color(30);

    printf("\n                                ARRAY GENERATOR                                 ");

    Color(15);
}

//---------------------------------------------
void PressButtons(){
do{

            system("cls");

            CursorPosition(32,10);

            Color(15);

            puts("PRESS ANY KEY");

            Sleep(700);


            system("cls");

            Color(0);

            CursorPosition(32,10);

            puts("PRESS ANY KEY");

            Sleep(700);

}while(!kbhit());

system("cls");
}
//--------------------------------------------
 //IMAGE 01
void HIS(){
    Color(11);
CursorPosition(2,1);    printline(" _  _ ___ ___");
CursorPosition(2,2);   printline("| || |_ _/ __|");
CursorPosition(2,3);   printline("| __ || |\\_  \\");
CursorPosition(2,4);   printline("|_||_|___|___/");

}
    //IMAGE02
void ASD3(){
    Color(11);
CursorPosition(50,1);    printline("   _____ _____ ____  ___ ");
CursorPosition(50,2);    printline("  |  _  |   __|    \\|_  |");
CursorPosition(50,3);    printline("  |     |__   |  |  |_  |");
CursorPosition(50,4);    printline("  |__|__|_____|____/|___|");
                      }

    //PRINTER IMAGE 01 && 02
void printline(char p[]){
int i=0;
while(p[i]!=NULL){ Sleep(15);
    printf("%c",p[i++]);

} printf("\n");
}

//---------------------------------------------
void OPSCREEN(){

    HIS();

    ASD3();

    Color(240);

    CursorPosition(16,7);

    TypeWritter("SORTING ALGOTRITHMS");

    Color(176);

    CursorPosition(27,11);

    TypeWritter("CODED BY");

    Color(15);

    CursorPosition(1,15);

    TypeWritter("BENYAKOUB ISLAM");

    CursorPosition(45,15);

    TypeWritter("BENALIA YOUCEF");
}
//-------------///------------------------------///----------------------------//

void SwitchScreen(char p[]){

    system("cls");

    puts("");Color(59);

    printf("                                 TRI %s                                  ",p);

    Color(15);puts("");

}

////////--------------------------------------/-///////////-------------------------------/------//

void Menu(){
                system("cls");

                Color(48);

                puts("\n                                    MENU                                        ");

                sleep(1);

                Color(11);
                puts("\n   1>_GENERATE ARRAY");Sleep(500);
                puts("\n   2>_TRI <BULLE>");Sleep(500);
                puts("\n   3>_TRI <INSERTION>");Sleep(500);
                puts("\n   4>_TRI <SELECTION>");Sleep(500);
                puts("\n   5>_TRI <RAPIDE>");Sleep(500);
                puts("\n   6>_TRI <FUSION>");Sleep(500);
                puts("\n   7>_TEST EXE TIME");Sleep(500);
                Color(224);
                puts("\n   8>_EXIT");Sleep(500);
                Color(15);
}
//---------///--//--------------------////-----------------///---------------------///------------------//
   void StaticMenu(){

    Color(48);
    puts("\n                                    MENU                                        ");
    Color(11);
    puts("\n   1>_GENERATE ARRAY");
    puts("\n   2>_TRI <BULLE>");
    puts("\n   3>_TRI <INSERTION>");
    puts("\n   4>_TRI <SELECTION>");
    puts("\n   5>_TRI <RAPIDE>");
    puts("\n   6>_TRI <FUSION>");
    puts("\n   7>_TEST EXE TIME");
    Color(224);
    puts("\n   8>_EXIT");Sleep(500);
    Color(15);
}

///---------------------------------------------////-------------------------------------------------////-----//

//--------------------------------------------------



#endif
