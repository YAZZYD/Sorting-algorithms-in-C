#ifndef Algotri_h
#define AlgoTri_h

//----------------------------------------

void Permuter(int*a,int *b){        //Pour permuter les �lements de tableau

            int temp=*a;

            *a=*b;

            *b=temp; }

//-----------------------------------------

void TriBulle(int T[],int n){       //TRI A BULLE

    int permut,x=n;//x=n pour d�terminer la limite

    do{ permut=0;  // permut=0 (permut=false)

        --x;        //decrementer la limite

        for(int i=0;i<x;i++){

            if(T[i]>T[i+1]) {

                    Permuter(&T[i],&T[i+1]);

                    permut=1;}}
        }while(permut);

    }

//--------------------------------------------

void TriSelection(int T[],int n){   //TRI PAR SELECTION

  int i,j;

  for(i=0;i<=(n-1);i++){    //Comparer i eme element avec le reste du tableau

    for(j=i+1;j<n;j++){

      if(T[i]>T[j]){        //condition

          Permuter(&T[i],&T[j]); //permutation

         }}}
      }
//---------------------------------------------

void TriInsertion(int T[],int n){   //TRI PAR INSERTION

  int i,j,stop;

  for(i=1;i<n;i++){ // D�calage de position

    j=i-1; stop=0;

    while(j>=0 && !stop){ // V�rification des �lements pr�cedents

        if(T[j+1]>=T[j]) stop=1; // Si element courant > element precedent stop

        else{

            Permuter(&T[j+1],&T[j]);// Sinon permuter

            j--;}}}         // passe � l'element pr�cedant
        }
//-----------------------------------------------

int Partitionner(int T[],int inf,int sup){  // Partitionner: la fonction retourne l'indice de milieu du tableau (posPivot)

  int pivot=T[sup];

  int posPivot=inf;

  for(int i=inf;i<sup;i++){

        if(T[i]<=pivot){

            Permuter(&T[i],&T[posPivot]);

            posPivot++;
        }}

    Permuter(&T[posPivot],&T[sup]);

    return posPivot;

    }
//------------------------------------------------

void TriRapide(int T[],int inf,int sup){    //TRI RAPIDE
 int posPivot;
 if(inf<sup){
   posPivot=Partitionner(T,inf,sup);    //Milieu du tableau[inf..sup]
   TriRapide(T,inf,posPivot-1);         //Milieu du tableau[inf..milieu]
   TriRapide(T,posPivot+1,sup);         //Milieu du tableau[milieu+1..sup]
 }}

 //------------------------------------------------



void Fusion(int T[],int deb,int demi,int fin)
{
    int i,j,k;
    int n1=demi-deb+1;
    int n2=fin-demi;

    int L[n1],R[n2];

    for (i=0;i<n1;i++){

        L[i] = T[deb + i];
    }

    for (j = 0; j < n2; j++){

        R[j] = T[demi + 1 + j];
    }


    i=0;  j=0;    k=deb;


    while (i< n1 && j<n2) {
            if (L[i] <= R[j]) {
                T[k] = L[i];
                i++;
        }else {
            T[k] = R[j];
            j++;
        }
        k++;
    }
    while (i < n1) {
        T[k] = L[i];
        i++;
        k++;
    }
    while (j < n2) {
        T[k] = R[j];
        j++;
        k++;
    }
}
//---------------------------------------------------

void TriFusion(int T[], int deb, int fin){  //TRI FUSION
    int demi;
        if(deb<fin){

            demi=deb+(fin-deb)/2; // Milieu du tableau
            //printf("%d\n",demi);

            TriFusion(T,deb,demi); // Partitionner recursivement le tableau

            TriFusion(T,demi+1,fin);// jusqu'� chaque element sera pris individuelement

            Fusion(T,deb,demi,fin);//trie et fusionner les deux tranches du tableau
        }
        }
#endif // Algotri_h

